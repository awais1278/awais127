<?php
/**
 * Electro ACF Hooks
 *
 * @package  electro
 */

require_once get_template_directory() . '/inc/acf/hooks/home-v10-hooks.php';
require_once get_template_directory() . '/inc/acf/hooks/home-v11-hooks.php';
require_once get_template_directory() . '/inc/acf/hooks/home-v12-hooks.php';
