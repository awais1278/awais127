<?php
/**
 * Template tags used in Homepages
 */

require_once get_template_directory() . '/inc/template-tags/homepages/home-v1.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-v2.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-v3.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-v4.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-v5.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-v6.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-v7.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-v8.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-v9.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-v10.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-v11.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-v12.php';
require_once get_template_directory() . '/inc/template-tags/homepages/mobile.php';
require_once get_template_directory() . '/inc/template-tags/homepages/home-mobile.php';
