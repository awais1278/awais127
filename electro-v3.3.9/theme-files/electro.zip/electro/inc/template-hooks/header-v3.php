<?php
/**
 * Template hooks used in Header v3
 */
add_action( 'electro_header_v3', 'electro_masthead', 10 );
add_action( 'electro_header_v3', 'electro_navbar_primary_menu', 20 );